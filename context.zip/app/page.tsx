// app/page.tsx
"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  Gavel,
  Trophy,
  Timer,
  Wallet,
  Radio,
  Users,
  ArrowRight,
  ShieldCheck,
  Shuffle,
  Tv,
  ChevronRight,
  Layers,
  CloudSun,
} from "lucide-react";

/* ─────────────────────────────────────────────────────────────────────────
   GLOBAL STYLES — shares the same font stack + CSS variable names as the
   rest of the app (Archivo Narrow / Geist Mono / Inter, --color-* tokens).
   If globals.css already defines --color-* this inherits them; the :root
   fallback block below only fires if this page is dropped in standalone.
──────────────────────────────────────────────────────────────────────── */
const GLOBAL_STYLES = `
  @import url('https://fonts.googleapis.com/css2?family=Archivo+Narrow:ital,wght@0,400;0,600;0,700;1,700&family=Inter:wght@400;500;600;700&family=Geist+Mono:wght@400;500;600;700;800&display=swap');

  :root {
    --color-background: #0b0d0d;
    --color-on-background: #f0ede6;
    --color-surface-container-low: #121615;
    --color-surface-container: #171c1a;
    --color-surface-container-high: #1e2422;
    --color-on-surface: #f0ede6;
    --color-on-surface-variant: #c7cdd0;
    --color-outline: #6f7d80;
    --color-border-overlay: rgba(255,255,255,0.08);
    --color-theme-orange: #c9971f;
    --color-status-live: #ff8a7a;
  }

  .lp-root { font-family: 'Inter', sans-serif; }
  .lp-display { font-family: 'Archivo Narrow', sans-serif; font-style: italic; font-weight: 700; text-transform: uppercase; letter-spacing: -0.01em; }
  .lp-mono    { font-family: 'Geist Mono', monospace; text-transform: uppercase; letter-spacing: 0.16em; }

  @keyframes lp-drift {
    0%,100% { transform: translate(0,0); }
    50%     { transform: translate(-2%, 2%); }
  }
  @keyframes lp-pulse-dot {
    0%,100% { opacity: 1; }
    50%     { opacity: 0.35; }
  }
  @keyframes lp-stamp {
    0%   { opacity: 0; transform: rotate(-11deg) scale(2.4); filter: blur(10px); }
    60%  { opacity: 1; filter: blur(0); }
    75%  { transform: rotate(-11deg) scale(0.95); }
    100% { transform: rotate(-11deg) scale(1); }
  }
  .lp-stamp-in { animation: lp-stamp 0.5s cubic-bezier(0.22,1,0.36,1) both; }

  @media (prefers-reduced-motion: reduce) {
    .lp-stamp-in, .lp-bg-drift { animation: none !important; }
  }
`;

/* ─────────────────────────────────────────────────────────────────────────
   SIGNATURE ELEMENT — a live "lot card" that ticks through a real bidding
   sequence and lands a SOLD stamp, on a loop. This is the actual product,
   staged as the hero, rather than an illustration of it.
──────────────────────────────────────────────────────────────────────── */
const DEMO_PLAYERS = [
  { name: "R. Fernando", role: "ALL-ROUNDER", base: 20000, bids: [20000, 28000, 34000, 41000], team: "STK" },
  { name: "A. Perera", role: "FAST BOWLER", base: 15000, bids: [15000, 19000, 22000], team: "RGL" },
  { name: "K. de Silva", role: "OPENER", base: 25000, bids: [25000, 33000, 40000, 46000, 52000], team: "VLC" },
];

function LiveLotCard() {
  const [playerIdx, setPlayerIdx] = useState(0);
  const [bidIdx, setBidIdx] = useState(0);
  const [phase, setPhase] = useState<"bidding" | "sold" | "pause">("bidding");

  const player = DEMO_PLAYERS[playerIdx];

  useEffect(() => {
    let t: ReturnType<typeof setTimeout>;

    if (phase === "bidding") {
      if (bidIdx < player.bids.length - 1) {
        t = setTimeout(() => setBidIdx((i) => i + 1), 850);
      } else {
        t = setTimeout(() => setPhase("sold"), 1000);
      }
    } else if (phase === "sold") {
      t = setTimeout(() => setPhase("pause"), 2200);
    } else {
      t = setTimeout(() => {
        setPlayerIdx((i) => (i + 1) % DEMO_PLAYERS.length);
        setBidIdx(0);
        setPhase("bidding");
      }, 600);
    }
    return () => clearTimeout(t);
  }, [phase, bidIdx, player.bids.length]);

  const currentBid = player.bids[bidIdx];
  const sold = phase === "sold" || phase === "pause";

  return (
    <div
      className="relative w-full max-w-[380px] rounded-2xl overflow-hidden"
      style={{
        background: "var(--color-surface-container-low)",
        border: "1px solid var(--color-border-overlay)",
        boxShadow: "0 30px 80px -20px rgba(0,0,0,0.6), 0 0 0 1px rgba(201,151,31,0.06)",
      }}
    >
      {/* status strip */}
      <div
        className="flex items-center justify-between px-4 py-2.5"
        style={{ borderBottom: "1px solid var(--color-border-overlay)" }}
      >
        <div className="flex items-center gap-2">
          <span
            className="w-1.5 h-1.5 rounded-full"
            style={{ background: "var(--color-status-live)", animation: "lp-pulse-dot 1.4s ease-in-out infinite" }}
          />
          <span className="lp-mono text-[9px]" style={{ color: "var(--color-status-live)" }}>
            On the block
          </span>
        </div>
        <span className="lp-mono text-[9px]" style={{ color: "var(--color-outline)" }}>
          Lot #{playerIdx + 4}
        </span>
      </div>

      {/* player */}
      <div className="px-5 pt-5 pb-4">
        <p className="lp-mono text-[9px] mb-1" style={{ color: "var(--color-theme-orange)" }}>
          {player.role}
        </p>
        <h3 className="lp-display text-[28px] leading-none" style={{ color: "var(--color-on-surface)" }}>
          {player.name}
        </h3>
      </div>

      {/* bid block */}
      <div className="relative mx-5 mb-5 rounded-xl px-4 pt-4 pb-4" style={{ background: "rgba(201,151,31,0.06)", border: "1px solid rgba(201,151,31,0.18)" }}>
        <p className="lp-mono text-[8px] mb-1" style={{ color: "var(--color-outline)" }}>
          Current bid
        </p>
        <div className="flex items-baseline gap-2">
          <span className="lp-display text-[40px] leading-none tabular-nums" style={{ color: "var(--color-theme-orange)" }}>
            {currentBid.toLocaleString()}
          </span>
          <span className="lp-mono text-[9px]" style={{ color: "var(--color-outline)" }}>pts</span>
        </div>

        {sold && (
          <div className="absolute -top-4 -right-3 pointer-events-none">
            <div
              className="lp-stamp-in px-3 py-1 rounded-md"
              style={{ border: "3px solid #C9971F", background: "rgba(11,13,13,0.85)" }}
            >
              <span className="lp-display text-[15px] not-italic" style={{ color: "#E8C468", letterSpacing: "0.08em" }}>
                SOLD → {player.team}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* purse bar filler, for texture */}
      <div className="px-5 pb-5 flex items-center gap-3">
        <Timer className="w-3.5 h-3.5 shrink-0" style={{ color: "var(--color-outline)" }} />
        <div className="flex-1 h-1 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.06)" }}>
          <div
            className="h-full rounded-full transition-all duration-500"
            style={{
              width: phase === "bidding" ? `${((bidIdx + 1) / player.bids.length) * 100}%` : "100%",
              background: sold ? "#6b7280" : "var(--color-theme-orange)",
            }}
          />
        </div>
        <span className="lp-mono text-[8px]" style={{ color: "var(--color-outline)" }}>
          {sold ? "closed" : "live"}
        </span>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   Small bracket motif — reuses the elbow-connector language from the real
   tournament bracket component, just enough to read as "this app draws
   brackets," used inside the Tournament module card.
──────────────────────────────────────────────────────────────────────── */
function BracketGlyph() {
  return (
    <svg viewBox="0 0 220 120" className="w-full h-auto">
      {[
        "M4 12 L40 12 Q48 12 48 20 L48 40 Q48 48 56 48 L96 48",
        "M4 32 L40 32 Q48 32 48 40 L48 40",
        "M4 52 L40 52 Q48 52 48 60 L48 88 Q48 96 56 96 L96 96",
        "M4 72 L40 72 Q48 72 48 80 L48 88",
        "M96 48 L96 48",
      ].map((d, i) => (
        <path key={i} d={d} fill="none" stroke="rgba(255,255,255,0.14)" strokeWidth="2" />
      ))}
      <path
        d="M96 48 Q104 48 104 56 L104 88 Q104 96 112 96 L216 96"
        fill="none"
        stroke="#C9971F"
        strokeWidth="2.5"
        strokeOpacity="0.9"
      />
      {[12, 32, 52, 72].map((y, i) => (
        <circle key={i} cx="4" cy={y} r="3" fill="rgba(255,255,255,0.3)" />
      ))}
      <circle cx="216" cy="96" r="4" fill="#E8C468" />
    </svg>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   PAGE
──────────────────────────────────────────────────────────────────────── */
export default function LandingPage() {
  return (
    <div className="lp-root min-h-screen w-full overflow-x-hidden" style={{ background: "var(--color-background)", color: "var(--color-on-background)" }}>
      <style>{GLOBAL_STYLES}</style>

      {/* ambient backdrop */}
      <div
        className="fixed inset-0 pointer-events-none lp-bg-drift"
        style={{
          background: `
            radial-gradient(circle at 15% -10%, rgba(201,151,31,0.10) 0%, transparent 45%),
            radial-gradient(circle at 100% 20%, rgba(255,138,122,0.05) 0%, transparent 40%)
          `,
          animation: "lp-drift 18s ease-in-out infinite",
        }}
      />

      {/* ── NAV ── */}
      <header className="relative z-10 max-w-[1280px] mx-auto flex items-center justify-between px-6 md:px-10 py-6">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: "rgba(201,151,31,0.12)", border: "1px solid rgba(201,151,31,0.3)" }}>
            <Gavel className="w-4 h-4" style={{ color: "var(--color-theme-orange)" }} />
          </div>
          <span className="lp-display text-[19px] not-italic" style={{ color: "var(--color-on-surface)" }}>
            Gavel
          </span>
        </div>
        <nav className="hidden md:flex items-center gap-8 lp-mono text-[10px]" style={{ color: "var(--color-on-surface-variant)" }}>
          <a href="#modules" className="hover:opacity-70 transition-opacity">Modules</a>
          <a href="#flow" className="hover:opacity-70 transition-opacity">How it runs</a>
          <a href="#features" className="hover:opacity-70 transition-opacity">Features</a>
        </nav>
        <Link
          href="/auction/admin"
          className="lp-mono text-[10px] px-4 py-2 rounded-full flex items-center gap-1.5"
          style={{ background: "var(--color-theme-orange)", color: "#1a1304" }}
        >
          Open admin <ArrowRight className="w-3 h-3" />
        </Link>
      </header>

      {/* ── HERO ── */}
      <section className="relative z-10 max-w-[1280px] mx-auto px-6 md:px-10 pt-10 md:pt-16 pb-20 grid md:grid-cols-2 gap-14 items-center">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full mb-6" style={{ background: "var(--color-surface-container)", border: "1px solid var(--color-border-overlay)" }}>
            <Radio className="w-3 h-3" style={{ color: "var(--color-status-live)" }} />
            <span className="lp-mono text-[9px]" style={{ color: "var(--color-on-surface-variant)" }}>
              Live auction &amp; tournament engine
            </span>
          </div>

          <h1 className="lp-display text-[46px] leading-[0.95] md:text-[62px] mb-6" style={{ color: "var(--color-on-surface)" }}>
            Auction day,<br />
            without the <span style={{ color: "var(--color-theme-orange)" }}>chaos.</span>
          </h1>

          <p className="text-[15px] leading-relaxed max-w-md mb-8" style={{ color: "var(--color-on-surface-variant)" }}>
            Build your team roster, run a live player auction with a real shot
            clock and purse tracking, then feed the results straight into a
            single or double-elimination bracket. One tool, from the draft
            table to the final.
          </p>

          <div className="flex flex-wrap items-center gap-3">
            <Link
              href="/auction/admin"
              className="lp-mono text-[10px] px-6 py-3.5 rounded-lg flex items-center gap-2"
              style={{ background: "var(--color-theme-orange)", color: "#1a1304" }}
            >
              <Gavel className="w-3.5 h-3.5" />
              Start an auction
            </Link>
            <Link
              href="/tournament/admin"
              className="lp-mono text-[10px] px-6 py-3.5 rounded-lg flex items-center gap-2"
              style={{ background: "transparent", border: "1px solid var(--color-border-overlay)", color: "var(--color-on-surface)" }}
            >
              <Trophy className="w-3.5 h-3.5" />
              Build a bracket
            </Link>
          </div>

          <div className="flex items-center gap-6 mt-10 lp-mono text-[9px]" style={{ color: "var(--color-outline)" }}>
            <span>No install — runs in the browser</span>
            <span className="w-1 h-1 rounded-full" style={{ background: "var(--color-outline)" }} />
            <span>Owners bid from their phones</span>
          </div>
        </div>

        <div className="flex justify-center md:justify-end">
          <LiveLotCard />
        </div>
      </section>

      {/* ── MODULES ── */}
      <section id="modules" className="relative z-10 max-w-[1280px] mx-auto px-6 md:px-10 py-16">
        <div className="mb-10">
          <p className="lp-mono text-[9px] mb-2" style={{ color: "var(--color-theme-orange)" }}>Three modules, one league</p>
          <h2 className="lp-display text-[30px] md:text-[36px]" style={{ color: "var(--color-on-surface)" }}>
            Everything between the draft and the trophy.
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-5">
          {/* Auction card */}
          <div className="rounded-2xl p-7 relative overflow-hidden" style={{ background: "var(--color-surface-container-low)", border: "1px solid var(--color-border-overlay)" }}>
            <div className="flex items-center gap-3 mb-5">
              <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: "rgba(201,151,31,0.12)", border: "1px solid rgba(201,151,31,0.3)" }}>
                <Gavel className="w-4 h-4" style={{ color: "var(--color-theme-orange)" }} />
              </div>
              <h3 className="lp-display text-[22px]" style={{ color: "var(--color-on-surface)" }}>Auction Room</h3>
            </div>
            <p className="text-[13.5px] leading-relaxed mb-6" style={{ color: "var(--color-on-surface-variant)" }}>
              Load your player pool, shuffle the lot order, and run the sale
              live. A shot clock locks bidding on time, purses update in
              real time, and every owner watches from their own screen.
            </p>
            <ul className="space-y-2.5 mb-2">
              {[
                "Purse &amp; squad-size limits enforced automatically",
                "Owner bid rooms, built for mobile",
                "Unsold-player re-entry rounds",
                "Live bidding feed for the auctioneer",
              ].map((f) => (
                <li key={f} className="flex items-start gap-2 text-[12.5px]" style={{ color: "var(--color-on-surface-variant)" }}>
                  <ChevronRight className="w-3.5 h-3.5 mt-0.5 shrink-0" style={{ color: "var(--color-theme-orange)" }} />
                  <span dangerouslySetInnerHTML={{ __html: f }} />
                </li>
              ))}
            </ul>
          </div>

          {/* Tournament card */}
          <div className="rounded-2xl p-7 relative overflow-hidden" style={{ background: "var(--color-surface-container-low)", border: "1px solid var(--color-border-overlay)" }}>
            <div className="flex items-center gap-3 mb-5">
              <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: "rgba(201,151,31,0.12)", border: "1px solid rgba(201,151,31,0.3)" }}>
                <Trophy className="w-4 h-4" style={{ color: "var(--color-theme-orange)" }} />
              </div>
              <h3 className="lp-display text-[22px]" style={{ color: "var(--color-on-surface)" }}>Tournament Bracket</h3>
            </div>
            <p className="text-[13.5px] leading-relaxed mb-4" style={{ color: "var(--color-on-surface-variant)" }}>
              Draw the teams your auction just built into a single or
              double-elimination bracket. Record results as they happen and
              the bracket, and the champion, update on their own.
            </p>
            <div className="mb-4 opacity-90"><BracketGlyph /></div>
            <ul className="space-y-2.5">
              {[
                "Single &amp; double elimination formats",
                "Live-match highlighting as you record scores",
                "Mobile-friendly round-by-round view",
              ].map((f) => (
                <li key={f} className="flex items-start gap-2 text-[12.5px]" style={{ color: "var(--color-on-surface-variant)" }}>
                  <ChevronRight className="w-3.5 h-3.5 mt-0.5 shrink-0" style={{ color: "var(--color-theme-orange)" }} />
                  <span dangerouslySetInnerHTML={{ __html: f }} />
                </li>
              ))}
            </ul>
          </div>

          {/* Overlay card */}
          <div className="rounded-2xl p-7 relative overflow-hidden" style={{ background: "var(--color-surface-container-low)", border: "1px solid var(--color-border-overlay)" }}>
            <div className="flex items-center gap-3 mb-5">
              <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: "rgba(201,151,31,0.12)", border: "1px solid rgba(201,151,31,0.3)" }}>
                <Layers className="w-4 h-4" style={{ color: "var(--color-theme-orange)" }} />
              </div>
              <h3 className="lp-display text-[22px]" style={{ color: "var(--color-on-surface)" }}>Broadcast Overlays</h3>
            </div>
            <p className="text-[13.5px] leading-relaxed mb-4" style={{ color: "var(--color-on-surface-variant)" }}>
              A transparent, OBS-ready page you drop straight into your
              stream. Toggle each piece on and off from the admin console —
              nothing to re-render, nothing to restart.
            </p>
            <div className="mb-4 flex items-center gap-1.5 flex-wrap">
              {[
                { icon: CloudSun, label: "Weather" },
                { icon: Radio, label: "Boundaries" },
                { icon: Tv, label: "Score bar" },
                { icon: Trophy, label: "Points table" },
              ].map((chip) => (
                <span
                  key={chip.label}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full lp-mono text-[8px]"
                  style={{ background: "var(--color-surface-container)", border: "1px solid var(--color-border-overlay)", color: "var(--color-on-surface-variant)" }}
                >
                  <chip.icon className="w-2.5 h-2.5" style={{ color: "var(--color-theme-orange)" }} />
                  {chip.label}
                </span>
              ))}
            </div>
            <ul className="space-y-2.5">
              {[
                "Scorecard, match intro &amp; tournament logo stings",
                "Boundary counters for the match and the tournament",
                "Every piece syncs live from the admin — no manual refresh",
              ].map((f) => (
                <li key={f} className="flex items-start gap-2 text-[12.5px]" style={{ color: "var(--color-on-surface-variant)" }}>
                  <ChevronRight className="w-3.5 h-3.5 mt-0.5 shrink-0" style={{ color: "var(--color-theme-orange)" }} />
                  <span dangerouslySetInnerHTML={{ __html: f }} />
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* ── FLOW ── */}
      <section id="flow" className="relative z-10 max-w-[1280px] mx-auto px-6 md:px-10 py-16">
        <div className="mb-10">
          <p className="lp-mono text-[9px] mb-2" style={{ color: "var(--color-theme-orange)" }}>How an auction day runs</p>
          <h2 className="lp-display text-[30px] md:text-[36px]" style={{ color: "var(--color-on-surface)" }}>
            Six steps, start to trophy.
          </h2>
        </div>

        <div className="grid md:grid-cols-3 lg:grid-cols-6 gap-4">
          {[
            { icon: Users, title: "Build the roster", body: "Add teams and the player pool with base prices." },
            { icon: ShieldCheck, title: "Set the rules", body: "Purse size, squad limits, bid increments, timer." },
            { icon: Shuffle, title: "Shuffle the order", body: "Lock in a fair, random lot sequence before you go live." },
            { icon: Gavel, title: "Run the sale", body: "Owners bid live, the clock locks it, you hammer it down." },
            { icon: Layers, title: "Flip on overlays", body: "Weather, score bar and boundaries, live on the stream." },
            { icon: Trophy, title: "Draw the bracket", body: "Move straight into a knockout with the teams you built." },
          ].map((s, i) => (
            <div key={s.title} className="rounded-xl p-5" style={{ background: "var(--color-surface-container)", border: "1px solid var(--color-border-overlay)" }}>
              <div className="flex items-center justify-between mb-4">
                <s.icon className="w-4 h-4" style={{ color: "var(--color-theme-orange)" }} />
                <span className="lp-mono text-[9px]" style={{ color: "var(--color-outline)" }}>{`0${i + 1}`}</span>
              </div>
              <h4 className="lp-display text-[15px] not-italic mb-1.5" style={{ color: "var(--color-on-surface)" }}>{s.title}</h4>
              <p className="text-[12px] leading-relaxed" style={{ color: "var(--color-on-surface-variant)" }}>{s.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── FEATURES ── */}
      <section id="features" className="relative z-10 max-w-[1280px] mx-auto px-6 md:px-10 py-16">
        <div className="grid md:grid-cols-4 gap-5">
          {[
            { icon: Timer, title: "Real shot clock", body: "Bidding locks the moment time runs out — no arguing over who bid first." },
            { icon: Wallet, title: "Purse tracking", body: "Every bid checks against what a team actually has left to spend." },
            { icon: Tv, title: "Live score bar", body: "Ball-by-ball chips, striker/non-striker, and bowler figures on a broadcast-ready overlay." },
            { icon: Trophy, title: "Bracket that updates itself", body: "Record a result and the next round, and the champion, fill in on their own." },
          ].map((f) => (
            <div key={f.title} className="rounded-xl p-6" style={{ background: "var(--color-surface-container-low)", border: "1px solid var(--color-border-overlay)" }}>
              <f.icon className="w-4 h-4 mb-4" style={{ color: "var(--color-theme-orange)" }} />
              <h4 className="lp-display text-[16px] not-italic mb-1.5" style={{ color: "var(--color-on-surface)" }}>{f.title}</h4>
              <p className="text-[13px] leading-relaxed" style={{ color: "var(--color-on-surface-variant)" }}>{f.body}</p>
            </div>
          ))}
        </div>

        {/* Live score bar callout — the overlay is distinctive enough to
            deserve its own moment, not just a line in the grid above. */}
        <div
          className="mt-5 rounded-2xl px-6 py-8 md:px-10 md:py-10 flex flex-col md:flex-row items-center gap-8"
          style={{ background: "var(--color-surface-container-low)", border: "1px solid var(--color-border-overlay)" }}
        >
          <div className="flex-1">
            <p className="lp-mono text-[9px] mb-2" style={{ color: "var(--color-theme-orange)" }}>Second-screen ready</p>
            <h3 className="lp-display text-[24px] md:text-[28px] mb-2" style={{ color: "var(--color-on-surface)" }}>
              A score bar built for the stream, not the spreadsheet.
            </h3>
            <p className="text-[13.5px] leading-relaxed max-w-md" style={{ color: "var(--color-on-surface-variant)" }}>
              Team crests, live score, current over shown ball-by-ball, and
              the batters and bowler at the crease — synced in real time and
              designed to sit at the bottom of a broadcast, not buried in an
              admin tab.
            </p>
          </div>
          <div
            className="w-full md:w-[380px] shrink-0 rounded-xl px-4 py-3 flex items-center justify-between gap-3"
            style={{ background: "var(--color-surface-container)", border: "1px solid var(--color-border-overlay)" }}
          >
            <div className="flex items-center gap-2">
              <span className="w-7 h-7 rounded-full flex items-center justify-center lp-mono text-[9px] font-bold" style={{ background: "var(--color-theme-orange)", color: "#1a1304" }}>
                STK
              </span>
              <span className="lp-display text-[20px] not-italic tabular-nums" style={{ color: "var(--color-on-surface)" }}>
                142<span style={{ color: "var(--color-outline)" }}>-3</span>
              </span>
            </div>
            <div className="flex items-center gap-1">
              {["4", "1", "W", ".", "6", "2"].map((b, i) => (
                <span
                  key={i}
                  className="w-5 h-5 rounded-full flex items-center justify-center text-[8px] font-bold"
                  style={{
                    background: b === "W" ? "#7c1d13" : b === "4" || b === "6" ? "var(--color-theme-orange)" : "rgba(255,255,255,0.08)",
                    color: b === "W" || b === "4" || b === "6" ? "#fff" : "var(--color-on-surface-variant)",
                  }}
                >
                  {b === "." ? "•" : b}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="relative z-10 max-w-[1280px] mx-auto px-6 md:px-10 pb-24">
        <div
          className="rounded-2xl px-8 py-14 md:px-16 md:py-16 flex flex-col md:flex-row items-start md:items-center justify-between gap-8"
          style={{ background: "linear-gradient(135deg, rgba(201,151,31,0.10), rgba(201,151,31,0.02))", border: "1px solid rgba(201,151,31,0.22)" }}
        >
          <div>
            <h2 className="lp-display text-[28px] md:text-[34px] mb-2" style={{ color: "var(--color-on-surface)" }}>
              Ready to run your auction?
            </h2>
            <p className="text-[14px]" style={{ color: "var(--color-on-surface-variant)" }}>
              Set up teams and players in minutes — go live whenever you're ready.
            </p>
          </div>
          <Link
            href="/auction/admin"
            className="lp-mono text-[11px] px-7 py-4 rounded-lg flex items-center gap-2 shrink-0"
            style={{ background: "var(--color-theme-orange)", color: "#1a1304" }}
          >
            <Gavel className="w-4 h-4" />
            Open the admin console
          </Link>
        </div>
      </section>

      <footer className="relative z-10 max-w-[1280px] mx-auto px-6 md:px-10 pb-10 flex items-center justify-between lp-mono text-[9px]" style={{ color: "var(--color-outline)" }}>
        <span>Gavel — auction &amp; tournament tools</span>
        <span>Built for cricket leagues, works for any draft</span>
      </footer>
    </div>
  );
}