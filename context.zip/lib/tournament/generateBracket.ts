import { supabase } from "@/lib/supabase";
import type { Round, MatchNode } from "@/components/tournament/TournamentBracket";
import type { DoubleElimData } from "@/lib/tournament/doubleElim";
import { generateSingleElimination } from "@/lib/tournament/singleElim";
import { generateDoubleElimination } from "@/lib/tournament/doubleElim";
import { randomDraw, type AdminTeam } from "@/lib/tournament/seeding";

export type SeedingMethod = "random" | "creation_order";

export interface GenerateBracketResult {
  ok: boolean;
  error?: string;
}

/**
 * Checks whether bracket_matches already has any rows for this tournament —
 * used to gate the "Generate" button (show "Regenerate" instead) without
 * fetching the full bracket.
 */
export async function hasBracketGenerated(tournamentId: string): Promise<boolean> {
  const { count, error } = await supabase
    .from("bracket_matches")
    .select("id", { count: "exact", head: true })
    .eq("tournament_id", tournamentId);
  if (error) {
    console.error("hasBracketGenerated failed:", error.message);
    return false;
  }
  return !!count && count > 0;
}

/**
 * Deletes every bracket_matches row for a tournament — call before
 * generateBracketForTournament if you want to regenerate from scratch.
 *
 * IMPORTANT: Supabase/PostgREST does not throw an error when a RLS DELETE
 * policy silently filters out every row a delete would otherwise match —
 * it just reports success with zero rows affected. `.select("id")` forces
 * the response to include the rows that were actually deleted, so we can
 * tell the difference between "deleted everything" and "deleted nothing
 * because RLS blocked it" instead of reporting a false success.
 */
export async function deleteBracketForTournament(tournamentId: string): Promise<GenerateBracketResult> {
  // Break the circular FK first: bracket_matches.overlay_match_id -> matches.id
  // means matches can't be deleted while bracket_matches still points at them.
  const { error: clearOverlayErr } = await supabase
    .from("bracket_matches")
    .update({ overlay_match_id: null })
    .eq("tournament_id", tournamentId);

  if (clearOverlayErr) {
    return { ok: false, error: `Couldn't unlink overlay matches: ${clearOverlayErr.message}` };
  }

  // Now safe to delete matches tied to this tournament.
  const { error: matchesErr } = await supabase
    .from("matches")
    .delete()
    .eq("tournament_id", tournamentId);

  if (matchesErr) {
    return { ok: false, error: `Couldn't clear linked matches: ${matchesErr.message}` };
  }

  const { data, error } = await supabase
    .from("bracket_matches")
    .delete()
    .eq("tournament_id", tournamentId)
    .select("id");

  if (error) return { ok: false, error: error.message };

  if (!data || data.length === 0) {
    return {
      ok: false,
      error:
        "No bracket rows were deleted — this usually means the DELETE row-level-security policy on bracket_matches is missing or doesn't match your org.",
    };
  }

  return { ok: true };
}

/**
 * Populates bracket_matches for a tournament from its linked auction's
 * teams. Refuses if a bracket already exists — call
 * deleteBracketForTournament first if the caller wants to regenerate.
 *
 * SEEDING SET: if the tournament has an explicit team selection saved
 * (tournament_teams has rows for it — see saveTournamentTeamSelection in
 * manualTeams.ts), only those teams are seeded into the bracket. If no
 * selection has ever been saved, every team under the linked auction is
 * seeded — same as before this table existed, so nothing changes for
 * tournaments that never touch the new team picker.
 *
 * Inserts are sequential (one row at a time, round by round) rather than
 * batched, so each row's real DB uuid is known before later rounds need
 * to reference it as a feeder_match_a_id/feeder_match_b_id — batching
 * with .select() would rely on Postgres preserving row order, which this
 * avoids entirely.
 */
export async function generateBracketForTournament(
  tournamentId: string,
  seeding: SeedingMethod = "random"
): Promise<GenerateBracketResult> {
  const { data: tournament, error: tErr } = await supabase
    .from("tournaments")
    .select("id, format, org_id")
    .eq("id", tournamentId)
    .single();
  if (tErr || !tournament) return { ok: false, error: "Tournament not found." };
  if (tournament.format === "round_robin") {
    return { ok: false, error: "Round-robin tournaments don't use a bracket." };
  }

  if (await hasBracketGenerated(tournamentId)) {
    return { ok: false, error: "A bracket already exists for this tournament." };
  }

  const { data: auction, error: aErr } = await supabase
    .from("auctions")
    .select("id")
    .eq("tournament_id", tournamentId)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (aErr) return { ok: false, error: aErr.message };
  if (!auction) return { ok: false, error: "No auction is linked to this tournament yet." };

  const { data: teamsRaw, error: teamsErr } = await supabase
    .from("teams")
    .select("id, code, name, color, logo, created_at")
    .eq("auction_id", auction.id)
    .order("created_at", { ascending: true });
  if (teamsErr) return { ok: false, error: teamsErr.message };
  if (!teamsRaw || teamsRaw.length === 0) {
    return { ok: false, error: "Need at least 2 teams to generate a bracket." };
  }

  // Narrow down to the tournament's selected subset, if one has been
  // explicitly saved. No rows in tournament_teams for this tournament
  // means "use everything under the linked auction" (the default).
  const { data: selectionRows, error: selErr } = await supabase
    .from("tournament_team_selections")
    .select("team_id")
    .eq("tournament_id", tournamentId);
  if (selErr) return { ok: false, error: selErr.message };

  const selectedIds = selectionRows && selectionRows.length > 0 ? new Set(selectionRows.map((r) => r.team_id)) : null;
  const eligibleTeams = selectedIds ? teamsRaw.filter((t) => selectedIds.has(t.id)) : teamsRaw;

  if (eligibleTeams.length < 2) {
    return {
      ok: false,
      error: selectedIds
        ? "Need at least 2 selected teams to generate a bracket — adjust your team selection above."
        : "Need at least 2 teams to generate a bracket.",
    };
  }

  const teams: AdminTeam[] = eligibleTeams.map((t) => ({
    id: t.id,
    code: t.code,
    name: t.name,
    color: t.color || undefined,
    logo: t.logo || undefined,
  }));
  const seeded = seeding === "random" ? randomDraw(teams) : teams;

try {
    if (tournament.format === "double_elimination") {
      const data = generateDoubleElimination(seeded);
      await insertDoubleElim(tournamentId, data);
    } else {
      const rounds = generateSingleElimination(seeded);
      await insertSingleElim(tournamentId, rounds);
    }

    // After bracket is generated successfully, create matches from bracket slots
    await createMatchesFromBracket(tournamentId, tournament.org_id);
  } catch (e: any) {
    // Insertion is sequential and non-transactional (see insertDoubleElim/
    // insertSingleElim) — if any row in the middle fails (bad feeder lookup,
    // RLS, transient network error), earlier rows are already committed.
    // Leaving those half-built rows in place is worse than an empty table:
    // buildDoubleEliminationData() returns null without a grand_final row,
    // which hides the "hasBracket" UI (no Regenerate button) while
    // hasBracketGenerated() still sees rows and blocks a fresh Generate —
    // a dead end the admin can't get out of from the UI. Clean up fully so
    // a failed attempt always leaves the tournament in a clean, regenerable
    // "no bracket" state instead.
    const cleanup = await deleteBracketForTournament(tournamentId);
    if (!cleanup.ok) {
      console.error(
        "generateBracketForTournament: failed to roll back partial bracket after error:",
        cleanup.error
      );
      return {
        ok: false,
        error: `${e?.message ?? "Failed to generate bracket."} (also failed to clean up the partial bracket — please contact support or clear bracket_matches for this tournament manually.)`,
      };
    }
    return { ok: false, error: e?.message ?? "Failed to generate bracket." };
  }

  return { ok: true };
}

/* ------------------------------------------------------------------ */
/*  Shared helpers                                                      */
/* ------------------------------------------------------------------ */

function realTeamId(team: MatchNode["teamA"]): string | null {
  if (!team || team.code === "BYE") return null;
  return team.id;
}

function realWinnerId(m: MatchNode): string | null {
  if (m.teamA?.isWinner && m.teamA.code !== "BYE") return m.teamA.id;
  if (m.teamB?.isWinner && m.teamB.code !== "BYE") return m.teamB.id;
  return null;
}

function stripPrefix(label: string | null): string | null {
  return label ? label.replace(/^[WL]:/, "") : null;
}

/* ------------------------------------------------------------------ */
/*  Single elimination insert                                           */
/* ------------------------------------------------------------------ */

async function insertSingleElim(tournamentId: string, rounds: Round[]) {
  const idMap = new Map<string, string>(); // generated match id -> real uuid

  for (let r = 0; r < rounds.length; r++) {
    const round = rounds[r];
    for (let i = 0; i < round.matches.length; i++) {
      const m = round.matches[i];
      const row = {
        tournament_id: tournamentId,
        bracket_type: "winners" as const,
        round: r + 1,
        position: i + 1,
        team_a_id: realTeamId(m.teamA),
        team_b_id: realTeamId(m.teamB),
        feeder_match_a_id: m.aFrom ? idMap.get(m.aFrom) ?? null : null,
        feeder_match_b_id: m.bFrom ? idMap.get(m.bFrom) ?? null : null,
        status: m.status === "completed" ? "completed" : "upcoming",
        winner_team_id: realWinnerId(m),
      };
      const { data, error } = await supabase.from("bracket_matches").insert(row).select("id").single();
      if (error || !data) throw new Error(error?.message ?? "Insert failed.");
      idMap.set(m.id, data.id);
    }
  }
}

/* ------------------------------------------------------------------ */
/*  Double elimination insert                                           */
/* ------------------------------------------------------------------ */

async function insertDoubleElim(tournamentId: string, data: DoubleElimData) {
  const idMap = new Map<string, string>();

  async function insertRound(round: Round, bracketType: "winners" | "losers", roundNumber: number) {
    for (let i = 0; i < round.matches.length; i++) {
      const m = round.matches[i];
      const feederA = stripPrefix(m.aFrom);
      const feederB = stripPrefix(m.bFrom);
      const row = {
        tournament_id: tournamentId,
        bracket_type: bracketType,
        round: roundNumber,
        position: i + 1,
        team_a_id: realTeamId(m.teamA),
        team_b_id: realTeamId(m.teamB),
        feeder_match_a_id: feederA ? idMap.get(feederA) ?? null : null,
        feeder_match_b_id: feederB ? idMap.get(feederB) ?? null : null,
        status: m.status === "completed" ? "completed" : "upcoming",
        winner_team_id: realWinnerId(m),
      };
      const { data: inserted, error } = await supabase.from("bracket_matches").insert(row).select("id").single();
      if (error || !inserted) throw new Error(error?.message ?? "Insert failed.");
      idMap.set(m.id, inserted.id);
    }
  }

  for (let ri = 0; ri < data.winners.length; ri++) {
    await insertRound(data.winners[ri], "winners", ri + 1);
  }
  for (let ri = 0; ri < data.losers.length; ri++) {
    await insertRound(data.losers[ri], "losers", ri + 1);
  }

  const gfFeederA = stripPrefix(data.grandFinal.aFrom);
  const gfFeederB = stripPrefix(data.grandFinal.bFrom);
  const { error: gfErr } = await supabase.from("bracket_matches").insert({
    tournament_id: tournamentId,
    bracket_type: "grand_final" as const,
    round: 1,
    position: 1,
    team_a_id: realTeamId(data.grandFinal.teamA),
    team_b_id: realTeamId(data.grandFinal.teamB),
    feeder_match_a_id: gfFeederA ? idMap.get(gfFeederA) ?? null : null,
    feeder_match_b_id: gfFeederB ? idMap.get(gfFeederB) ?? null : null,
    status: data.grandFinal.status === "completed" ? "completed" : "upcoming",
    winner_team_id: realWinnerId(data.grandFinal),
  });
  if (gfErr) throw new Error(gfErr.message);

  // bracketReset is only created in-memory after a real grand-final result
  // is recorded (see recordDoubleElimResult) — there's nothing to insert
  // for it yet at generation time.
}

/* ------------------------------------------------------------------ */
/*  Auto-create Matches from Bracket Slots                              */
/* ------------------------------------------------------------------ */

/**
 * After bracket is generated, automatically create a friendly match
 * for each bracket slot that has two teams. This ensures matches are
 * created immediately upon bracket generation, not as a separate step.
 */
async function createMatchesFromBracket(tournamentId: string, orgId: string): Promise<void> {
  // Fetch all bracket matches for this tournament
  const { data: bracketMatches, error: bracketErr } = await supabase
    .from("bracket_matches")
    .select("id, team_a_id, team_b_id, round, position")
    .eq("tournament_id", tournamentId)
    .order("round", { ascending: true })
    .order("position", { ascending: true });

  if (bracketErr || !bracketMatches) {
    console.error("createMatchesFromBracket: failed to fetch bracket matches", bracketErr?.message);
    return;
  }

  // Fetch team details for all teams in the bracket
  const teamIds = new Set<string>();
  bracketMatches.forEach((m) => {
    if (m.team_a_id) teamIds.add(m.team_a_id);
    if (m.team_b_id) teamIds.add(m.team_b_id);
  });

  if (teamIds.size === 0) return;

  const { data: teams, error: teamsErr } = await supabase
    .from("teams")
    .select("id, name, code, logo")
    .in("id", Array.from(teamIds));

  if (teamsErr || !teams) {
    console.error("createMatchesFromBracket: failed to fetch teams", teamsErr?.message);
    return;
  }

  const teamMap = new Map(teams.map((t) => [t.id, t]));

  // Get the tournament's linked auction for rosterLocked flag
  const { data: auction, error: auctionErr } = await supabase
    .from("auctions")
    .select("id, is_synthetic")
    .eq("tournament_id", tournamentId)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  const rosterLocked = auction && !auction.is_synthetic;

  // Create a match for each bracket slot with two teams
  for (const bracket of bracketMatches) {
    if (!bracket.team_a_id || !bracket.team_b_id) continue;

    const team1 = teamMap.get(bracket.team_a_id);
    const team2 = teamMap.get(bracket.team_b_id);
    if (!team1 || !team2) continue;

    const matchId = crypto.randomUUID();
    const matchSetup = {
      tournamentName: "",
      round: `Round ${bracket.round}, Match ${bracket.position}`,
      team1: { name: team1.name, short: team1.code, logo: team1.logo || "" },
      team2: { name: team2.name, short: team2.code, logo: team2.logo || "" },
      venue: "",
      date: "",
      time: "",
      toss: "",
      overs: 20,
      officials: { format: "", umpires: "", thirdUmpire: "", referee: "" },
      squads: [],
      rosterLocked,
      sourceAuctionId: auction?.id || null,
    };

    // Insert the match
    const { error: insertErr } = await supabase.from("matches").insert({
      id: matchId,
      auction_id: matchId,
      org_id: orgId,
      tournament_id: tournamentId,
      bracket_match_id: bracket.id,
      match_setup: matchSetup,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    });

    if (insertErr) {
      console.error("createMatchesFromBracket: failed to insert match", insertErr.message);
      // Continue creating other matches even if one fails
    }
  }
}
