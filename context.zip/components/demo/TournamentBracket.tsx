"use client";
import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { Trophy, Tv, MapPin, CheckCircle2, Radio, ChevronLeft, ChevronRight } from "lucide-react";

/* ------------------------------------------------------------------ */
/*  Public types — every piece of chart data flows through these      */
/* ------------------------------------------------------------------ */

export interface TeamNode {
  id: string;
  code: string;
  name: string;
  logo?: string;
  color: string;
  score?: number;
  isWinner?: boolean;
}

export interface MatchNode {
  id: string;
  label: string;
  status: "scheduled" | "live" | "completed";
  teamA: TeamNode | null;
  teamB: TeamNode | null;
  aFrom: string | null;
  bFrom: string | null;
  venue?: string;
  date?: string;
  time?: string;
}

export interface Round {
  id: number;
  name: string;
  shortName: string;
  matches: MatchNode[];
}

/* ------------------------------------------------------------------ */
/*  Component props — this is the entire surface for consumers        */
/* ------------------------------------------------------------------ */

export interface TournamentBracketProps {
  /** Full bracket data. rounds.length === number of levels in the bracket
   *  (Round of 32 -> ... -> Final). rounds[0] is the first round, the
   *  last entry must contain exactly one match (the Final). */
  rounds: Round[];
  /** Main heading shown in the header. */
  title?: string;
  /** Small uppercase label above the title (e.g. "Knockout Stage"). */
  eyebrowLabel?: string;
  /** Helper copy shown next to the live-match legend on desktop. */
  helperText?: string;
  /** Label for the live-match legend dot. */
  liveLabel?: string;
  /** Optional watermark/logo rendered behind the Final match. */
  logoSrc?: string;
  /** Extra classes applied to the outer wrapper. */
  className?: string;
  /** Called whenever the highlighted/selected team changes. */
  onActiveTeamChange?: (teamCode: string | null) => void;
}

const GROW_WEIGHT = {
  full: 2,
  semi: 1.2,
  quarter: 1.1,
  compact: 0.9,
};

/* ------------------------------------------------------------------ */
/*  Geometry helpers                                                   */
/* ------------------------------------------------------------------ */

function elbowPath(x1: number, y1: number, x2: number, y2: number, radius = 12): string {
  const midX = (x1 + x2) / 2;
  if (Math.abs(y2 - y1) < 1) return `M ${x1} ${y1} L ${x2} ${y2}`;
  const dir = y2 > y1 ? 1 : -1;
  const r = Math.max(0, Math.min(radius, Math.abs(y2 - y1) / 2, Math.abs(midX - x1)));
  return `M ${x1} ${y1} L ${midX - r} ${y1} Q ${midX} ${y1} ${midX} ${y1 + r * dir} L ${midX} ${
    y2 - r * dir
  } Q ${midX} ${y2} ${midX + r} ${y2} L ${x2} ${y2}`;
}

function topEntryPath(x1: number, y1: number, x2: number, y2: number, radius = 10): string {
  if (Math.abs(x2 - x1) < 1) return `M ${x1} ${y1} L ${x2} ${y2}`;
  const dir = y2 > y1 ? 1 : -1;
  const sign = x2 > x1 ? 1 : -1;
  const r = Math.max(0, Math.min(radius, Math.abs(x2 - x1), Math.abs(y2 - y1)));
  return `M ${x1} ${y1} L ${x2 - r * sign} ${y1} Q ${x2} ${y1} ${x2} ${y1 + r * dir} L ${x2} ${y2}`;
}

function computeCentersFromLeaves(leafCentersPx: number[], matchCountsPerRound: number[]): number[][] {
  const centers: number[][] = [leafCentersPx];
  for (let r = 1; r < matchCountsPerRound.length; r++) {
    const prev = centers[r - 1];
    const count = matchCountsPerRound[r];
    const next: number[] = [];
    for (let i = 0; i < count; i++) next.push((prev[i * 2] + prev[i * 2 + 1]) / 2);
    centers.push(next);
  }
  return centers;
}

type RefSetter = (el: HTMLDivElement | null) => void;

/* ------------------------------------------------------------------ */
/*  Presentational pieces (unchanged — pure functions of props)        */
/* ------------------------------------------------------------------ */

function TeamRow({
  team,
  status,
  fromLabel,
  hoveredTeamCode,
  setHoveredTeamCode,
  onFromClick,
  onTeamClick,
  isPinned,
  rowRef,
  compact,
}: {
  team: TeamNode | null;
  status: MatchNode["status"];
  fromLabel: string | null;
  hoveredTeamCode: string | null;
  setHoveredTeamCode: (c: string | null) => void;
  onFromClick?: () => void;
  /** Click a team to pin the highlight on it, so it stays lit while you
   *  move the mouse away or scroll — same mechanism as the double-elim
   *  board's MatchResultCard. */
  onTeamClick?: (code: string) => void;
  /** Whether this row's team is the currently pinned team. */
  isPinned?: boolean;
  rowRef?: RefSetter;
  compact?: boolean;
}) {
  const isTBD = !team;
  const isHovered = team && hoveredTeamCode === team.code;
  const isAnyHovered = hoveredTeamCode !== null;
  return (
    <div
      ref={rowRef}
      onMouseEnter={() => team && setHoveredTeamCode(team.code)}
      onMouseLeave={() => setHoveredTeamCode(null)}
      onClick={() => team && onTeamClick?.(team.code)}
      className={`flex items-center justify-between p-1 lg:p-1.5 rounded-lg relative transition-all duration-200 border ${
        isTBD ? "bg-background/40 border-dashed border-border-overlay text-outline" : "bg-surface-container border-border-overlay"
      } ${
        isHovered
          ? "scale-[1.02] border-theme-orange/40 bg-surface-container-high shadow-[0_0_20px_rgba(201,151,31,0.15)]"
          : isAnyHovered && !isHovered
          ? "opacity-30 blur-[0.5px]"
          : isPinned
          ? "border-theme-orange/50 bg-surface-container-high"
          : ""
      } ${!isTBD && onTeamClick ? "cursor-pointer" : ""}`}
    >
      {!isTBD && <span className="absolute left-0 top-2 bottom-2 w-1 rounded-r-md" style={{ backgroundColor: team.color }} />}
      <div className="flex items-center gap-2 lg:gap-3 pl-1.5 lg:pl-2 min-w-0">
        <span
          className={`w-6 h-6 lg:w-8 lg:h-8 rounded-full flex items-center justify-center shrink-0 bg-background overflow-hidden font-label-mono font-black text-[10px] lg:text-xs ${
            isTBD ? "border border-dashed border-outline/40" : ""
          }`}
        >
          {!isTBD ? (
            team.logo ? (
              <img src={team.logo} alt="" className="w-full h-full object-cover p-0.5" />
            ) : (
              <span style={{ color: team.color }}>{team.code}</span>
            )
          ) : (
            <span className="text-outline">?</span>
          )}
        </span>
        <div className="leading-none min-w-0">
          <p className={`font-label-mono font-bold text-xs uppercase tracking-wide truncate ${isTBD ? "text-outline font-medium" : "text-on-surface"}`}>
            {isTBD ? "To Be Determined" : team.name}
          </p>
          {!compact && (isTBD || fromLabel) && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onFromClick?.();
              }}
              disabled={!onFromClick}
              className="text-[9px] font-label-mono tracking-wider text-outline mt-0.5 flex items-center gap-1 disabled:cursor-default hover:text-theme-orange transition-colors"
            >
              {fromLabel ? (
                <>
                  <ChevronLeft className="w-2.5 h-2.5 text-theme-orange/70" />
                  {isTBD ? `Winner of ${fromLabel}` : `From ${fromLabel}`}
                </>
              ) : !isTBD ? (
                team.code
              ) : null}
            </button>
          )}
        </div>
      </div>
      {!isTBD && (
        <div className="flex items-center gap-1.5 pr-1 shrink-0">
          {isPinned && (
            <span className="hidden lg:inline-block text-[8px] font-label-mono font-black uppercase tracking-widest text-theme-orange border border-theme-orange/40 rounded px-1 py-0.5">
              Pinned
            </span>
          )}
          {status !== "scheduled" && (
            <div className="flex items-center gap-2 font-label-mono font-black text-sm">
              {team.isWinner && <CheckCircle2 className="w-3.5 h-3.5 text-theme-orange" strokeWidth={3} />}
              <span className={team.isWinner ? "text-theme-orange" : "text-outline"}>{team.score}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function MatchCard({
  match,
  hoveredTeamCode,
  setHoveredTeamCode,
  onFromClick,
  onTeamClick,
  pinnedTeamCode,
  getRef,
  compact,
  editable,
  onRecordResult,
}: {
  match: MatchNode;
  hoveredTeamCode: string | null;
  setHoveredTeamCode: (c: string | null) => void;
  onFromClick?: (label: string | null) => void;
  onTeamClick?: (code: string) => void;
  pinnedTeamCode?: string | null;
  getRef?: (key: string) => RefSetter;
  compact?: boolean;
  /** When true, and both teams are known (not TBD), renders an inline
   *  score + winner editor instead of (in addition to) the read-only
   *  footer. Clicking a team row selects it as the winner rather than
   *  pinning the hover-trace highlight. */
  editable?: boolean;
  onRecordResult?: (
    matchId: string,
    winner: "A" | "B",
    scoreA: number,
    scoreB: number
  ) => void | Promise<void>;
}) {
  const canEdit = !!editable && !!match.teamA && !!match.teamB;

  const [scoreA, setScoreA] = useState(match.teamA?.score?.toString() ?? "");
  const [scoreB, setScoreB] = useState(match.teamB?.score?.toString() ?? "");
  const [editWinner, setEditWinner] = useState<"A" | "B" | null>(
    match.teamA?.isWinner ? "A" : match.teamB?.isWinner ? "B" : null
  );
  const [saving, setSaving] = useState(false);
  const [editError, setEditError] = useState<string | null>(null);

  // Re-sync local edit state whenever the underlying match result changes
  // (e.g. after a save round-trips through router.refresh()).
  useEffect(() => {
    setScoreA(match.teamA?.score?.toString() ?? "");
    setScoreB(match.teamB?.score?.toString() ?? "");
    setEditWinner(match.teamA?.isWinner ? "A" : match.teamB?.isWinner ? "B" : null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [match.id, match.status, match.teamA?.score, match.teamB?.score]);

  async function handleSave() {
    if (!editWinner) {
      setEditError("Pick a winner first.");
      return;
    }
    const a = Number(scoreA);
    const b = Number(scoreB);
    if (scoreA === "" || scoreB === "" || Number.isNaN(a) || Number.isNaN(b)) {
      setEditError("Enter both scores.");
      return;
    }
    setEditError(null);
    setSaving(true);
    await onRecordResult?.(match.id, editWinner, a, b);
    setSaving(false);
  }

  const showFooter = !compact && (match.teamA || match.teamB);

  return (
    <div
      ref={getRef ? getRef(match.id) : undefined}
      className={`w-full rounded-xl relative overflow-hidden bg-surface-container-low border transition-colors duration-200 ${
        match.status === "live" ? "border-status-live/40 shadow-[0_0_24px_rgba(255,180,171,0.12)]" : "border-border-overlay shadow-2xl"
      }`}
    >
      {match.status === "live" && (
        <div className="absolute inset-0 bg-gradient-to-r from-status-live/5 to-theme-orange/5 pointer-events-none animate-pulse" />
      )}
      <div className="relative flex flex-col gap-1 lg:gap-1.5 p-1.5 lg:p-2">
        <TeamRow
          team={match.teamA}
          status={match.status}
          fromLabel={match.aFrom}
          hoveredTeamCode={hoveredTeamCode}
          setHoveredTeamCode={setHoveredTeamCode}
          onFromClick={onFromClick ? () => onFromClick(match.aFrom) : undefined}
          onTeamClick={canEdit ? () => setEditWinner("A") : onTeamClick}
          isPinned={canEdit ? editWinner === "A" : !!match.teamA && pinnedTeamCode === match.teamA.code}
          rowRef={getRef ? getRef(`${match.id}:A`) : undefined}
          compact={compact}
        />
        <TeamRow
          team={match.teamB}
          status={match.status}
          fromLabel={match.bFrom}
          hoveredTeamCode={hoveredTeamCode}
          setHoveredTeamCode={setHoveredTeamCode}
          onFromClick={onFromClick ? () => onFromClick(match.bFrom) : undefined}
          onTeamClick={canEdit ? () => setEditWinner("B") : onTeamClick}
          isPinned={canEdit ? editWinner === "B" : !!match.teamB && pinnedTeamCode === match.teamB.code}
          rowRef={getRef ? getRef(`${match.id}:B`) : undefined}
          compact={compact}
        />

        {canEdit && (
          <div className="flex items-center gap-2 border-t border-border-overlay pt-1.5 mt-0.5">
            <input
              type="number"
              value={scoreA}
              onChange={(e) => setScoreA(e.target.value)}
              placeholder="Score"
              className="w-14 bg-background border border-border-overlay rounded-md px-1.5 py-1 text-[11px] text-on-surface font-label-mono"
            />
            <span className="text-outline text-[10px] font-label-mono">vs</span>
            <input
              type="number"
              value={scoreB}
              onChange={(e) => setScoreB(e.target.value)}
              placeholder="Score"
              className="w-14 bg-background border border-border-overlay rounded-md px-1.5 py-1 text-[11px] text-on-surface font-label-mono"
            />
            <button
              type="button"
              onClick={handleSave}
              disabled={saving}
              className="ml-auto px-3 py-1.5 rounded-lg bg-theme-orange text-on-primary text-[10px] font-black uppercase tracking-widest disabled:opacity-50"
            >
              {saving ? "Saving…" : "Save"}
            </button>
          </div>
        )}
        {canEdit && editError && (
          <p className="text-status-live text-[10px] font-label-mono px-0.5">{editError}</p>
        )}

        {showFooter && !canEdit && (
          <div className="flex items-center justify-between border-t border-border-overlay pt-1 lg:pt-1.5 mt-0 text-[9px] lg:text-[10px] font-label-mono font-bold uppercase tracking-wider text-outline">
            <span className="hidden lg:flex items-center gap-1.5 max-w-[65%] truncate">
              <MapPin className="w-3 h-3 shrink-0" />
              <span className="truncate">{match.venue || "TBD"}</span>
            </span>
            <span className="flex lg:hidden items-center gap-1 truncate">
              <MapPin className="w-2.5 h-2.5 shrink-0" />
              <span className="truncate">{match.venue ? match.venue.split(" ")[0] : "TBD"}</span>
            </span>
            {match.status === "live" ? (
              <span className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-status-live/10 text-status-live border border-status-live/30 text-[9px] font-black tracking-widest">
                <Radio className="w-2.5 h-2.5 animate-pulse" />
                Live
              </span>
            ) : (
              <span className="flex items-center gap-1.5 text-outline">
                <Tv className="w-2.5 h-2.5 opacity-50 hidden lg:inline-block" />
                {match.date ? `${match.date}` : "TBD"}
              </span>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function BracketColumn({
  roundName,
  matches,
  centerYByMatchId,
  getRef,
  hoveredTeamCode,
  setHoveredTeamCode,
  onFromClick,
  onTeamClick,
  pinnedTeamCode,
  compact,
  isLeaf,
  leafColumnRef,
  growWeight = 1,
  bleedLeft,
  bleedRight,
  innerBleedLeft,
  innerBleedRight,
}: {
  roundName: string;
  matches: MatchNode[];
  centerYByMatchId?: Record<string, number>;
  getRef: (key: string) => RefSetter;
  hoveredTeamCode: string | null;
  setHoveredTeamCode: (c: string | null) => void;
  onFromClick?: (label: string | null) => void;
  onTeamClick?: (code: string) => void;
  pinnedTeamCode?: string | null;
  compact?: boolean;
  isLeaf?: boolean;
  leafColumnRef?: RefSetter;
  growWeight?: number;
  bleedLeft?: string;
  bleedRight?: string;
  innerBleedLeft?: string;
  innerBleedRight?: string;
}) {
  return (
    <div
      className="flex flex-col items-center min-w-0 relative h-full"
      style={{ flexGrow: growWeight, flexShrink: 1, flexBasis: 0 }}
    >
      <div className="w-full text-center mb-2 md:mb-3 lg:mb-4 relative z-10">
        <span className="inline-block px-2.5 py-1 lg:px-4 lg:py-1.5 rounded-full text-[9px] lg:text-[10px] font-black uppercase tracking-widest font-label-mono bg-surface-container-low border border-border-overlay text-on-surface-variant shadow-lg truncate max-w-full">
          {roundName}
        </span>
        <div className="absolute left-0 right-0 top-1/2 -z-10 h-px bg-gradient-to-r from-transparent via-border-overlay to-transparent" />
      </div>
      {isLeaf ? (
        <div
          ref={leafColumnRef}
          className="w-full min-h-0 flex flex-col items-stretch justify-between flex-1 gap-8 lg:gap-10"
        >
          {matches.map((match) => (
            <div key={match.id} className="w-full px-2">
              <MatchCard
                match={match}
                hoveredTeamCode={hoveredTeamCode}
                setHoveredTeamCode={setHoveredTeamCode}
                onFromClick={onFromClick}
                onTeamClick={onTeamClick}
                pinnedTeamCode={pinnedTeamCode}
                getRef={getRef}
                compact={compact}
              />
            </div>
          ))}
        </div>
      ) : (
        <div className="absolute inset-0 pointer-events-none z-10">
          {matches.map((match) => {
            const centerY = centerYByMatchId?.[match.id] ?? 0;
            return (
              <div
                key={match.id}
                ref={getRef(match.id)}
                className="absolute px-0.5 lg:px-1 pointer-events-auto"
                style={{
                  top: centerY,
                  transform: "translateY(-50%)",
                  left: bleedLeft || "0",
                  right: bleedRight || "0",
                }}
              >
                <div style={{ marginLeft: innerBleedLeft, marginRight: innerBleedRight }}>
                  <MatchCard
                    match={match}
                    hoveredTeamCode={hoveredTeamCode}
                    setHoveredTeamCode={setHoveredTeamCode}
                    onFromClick={onFromClick}
                    onTeamClick={onTeamClick}
                    pinnedTeamCode={pinnedTeamCode}
                    getRef={(key) => (key === match.id ? () => {} : getRef(key))}
                    compact={compact}
                  />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

interface Connector {
  id: string;
  d: string;
  teamCode?: string;
  sourceCode?: string;
}

/* ------------------------------------------------------------------ */
/*  Main component — everything about the bracket comes from props    */
/* ------------------------------------------------------------------ */

export default function TournamentBracket({
  rounds,
  title = "Championship Bracket",
  eyebrowLabel = "Knockout Stage",
  helperText = "Hover or click a team to trace their path.",
  liveLabel = "Live Matches",
  logoSrc,
  className = "",
  onActiveTeamChange,
}: TournamentBracketProps) {
  const [hoveredTeamCode, setHoveredTeamCode] = useState<string | null>(null);
  const [selectedTeamCode, setSelectedTeamCode] = useState<string | null>(null);
  const [mobileRound, setMobileRound] = useState(0);
  const mobileScrollRef = useRef<HTMLDivElement>(null);
  const desktopContainerRef = useRef<HTMLDivElement>(null);
  const leafColumnRef = useRef<HTMLDivElement | null>(null);
  const cardEls = useRef<Record<string, HTMLDivElement | null>>({});
  const refCache = useRef<Record<string, RefSetter>>({});
  const mobileVerticalRefs = useRef<Record<number, HTMLDivElement | null>>({});
  const [connectors, setConnectors] = useState<Connector[]>([]);

  const [matchCenterY, setMatchCenterY] = useState<Record<string, number>>({});
  const [finalCenter, setFinalCenter] = useState<{ x: number; y: number } | null>(null);
  const [columnHeight, setColumnHeight] = useState(1200);

  // "Levels" of the bracket == rounds.length, derived directly from the
  // data that was passed in — no hard-coded team count anywhere.
  const teamCount = rounds.length > 0 ? rounds[0].matches.length * 2 : 0;
  const useMirroredLayout = teamCount >= 16;

  // The bracket stage always claims the remaining viewport height (down
  // to the bottom of the screen) rather than sizing to its own content.
  // This is a real `height`, not a `min-height` — every round column is
  // stretched (`items-stretch` + `h-full`) to fill it, and each leaf
  // column spaces its matches out with `justify-between` so the first
  // and last card sit at the very top/bottom edge and everything else
  // is spread evenly between them. Because every parent-round match is
  // still positioned at the measured midpoint of the two matches that
  // feed it (see computeCentersFromLeaves/recomputeLayout below), this
  // spacing cascades correctly: each next-level match is always
  // centered on its two parent matches, all the way up to the Final.
  const stageHeightStyle = { height: "calc(100vh - 260px)" };

  function getRef(key: string): RefSetter {
    if (!refCache.current[key]) {
      refCache.current[key] = (el: HTMLDivElement | null) => {
        cardEls.current[key] = el;
      };
    }
    return refCache.current[key];
  }

  const finalRound = rounds[rounds.length - 1];
  const nonFinalRounds = rounds.slice(0, -1);
  const leftSideMatches = useMirroredLayout ? nonFinalRounds.map((r) => r.matches.slice(0, r.matches.length / 2)) : [];
  const rightSideMatches = useMirroredLayout ? nonFinalRounds.map((r) => r.matches.slice(r.matches.length / 2)) : [];

  function roundIndexForLabel(label: string | null): number {
    if (!label) return -1;
    const shortName = label.split("-")[0];
    return rounds.findIndex((r) => r.shortName === shortName);
  }

  function getRoundGrowWeight(roundIndex: number, side: "left" | "right" | "final"): number {
    if (side === "final") return GROW_WEIGHT.full * 1.3;
    const totalRounds = nonFinalRounds.length;
    if (roundIndex <= 1) return GROW_WEIGHT.full;
    if (roundIndex === 2 && totalRounds >= 4) return GROW_WEIGHT.quarter * 0.85;
    if (roundIndex === totalRounds - 1) return GROW_WEIGHT.semi * 0.85;
    return GROW_WEIGHT.compact;
  }

  function shouldBeCompact(_roundIndex: number): boolean {
    return false;
  }

  function recomputeLayout() {
    const containerEl = desktopContainerRef.current;
    if (!containerEl || !finalRound) return;
    const containerRect = containerEl.getBoundingClientRect();
    if (containerRect.width === 0) return;

    function measuredCenter(matchId: string): number | null {
      const el = cardEls.current[matchId];
      if (!el) return null;
      const r = el.getBoundingClientRect();
      if (r.height === 0) return null;
      return r.top + r.height / 2 - containerRect.top;
    }

    const nextCenters: Record<string, number> = {};
    if (useMirroredLayout) {
      const leftLeafY = leftSideMatches[0]?.map((m) => measuredCenter(m.id)) ?? [];
      const rightLeafY = rightSideMatches[0]?.map((m) => measuredCenter(m.id)) ?? [];
      if (leftLeafY.length === 0 || rightLeafY.length === 0) return;
      if (leftLeafY.some((v) => v === null) || rightLeafY.some((v) => v === null)) return;
      const leftCounts = leftSideMatches.map((r) => r.length);
      const rightCounts = rightSideMatches.map((r) => r.length);
      const leftPix = computeCentersFromLeaves(leftLeafY as number[], leftCounts);
      const rightPix = computeCentersFromLeaves(rightLeafY as number[], rightCounts);
      nonFinalRounds.forEach((_, r) => {
        leftSideMatches[r].forEach((m, i) => {
          nextCenters[m.id] = leftPix[r][i];
        });
        rightSideMatches[r].forEach((m, i) => {
          nextCenters[m.id] = rightPix[r][i];
        });
      });
      const lastLeft = leftPix[leftPix.length - 1][0];
      const lastRight = rightPix[rightPix.length - 1][0];
      nextCenters[finalRound.matches[0].id] = (lastLeft + lastRight) / 2;
    } else {
      const leafMatches = rounds[0]?.matches ?? [];
      const leafY = leafMatches.map((m) => measuredCenter(m.id));
      if (leafY.length === 0 || leafY.some((v) => v === null)) return;
      const counts = rounds.map((r) => r.matches.length);
      const pix = computeCentersFromLeaves(leafY as number[], counts);
      rounds.forEach((round, r) => {
        round.matches.forEach((m, i) => {
          nextCenters[m.id] = pix[r][i];
        });
      });
    }
    setMatchCenterY(nextCenters);
    const leafH = leafColumnRef.current?.scrollHeight;
    if (leafH && Math.abs(leafH - columnHeight) > 1) setColumnHeight(leafH);

    const finalCardEl = cardEls.current[finalRound.matches[0].id];
    if (finalCardEl) {
      const rect = finalCardEl.getBoundingClientRect();
      const x = rect.left + rect.width / 2 - containerRect.left;
      setFinalCenter({ x, y: nextCenters[finalRound.matches[0].id] });
    }
  }

  function recomputeConnectors() {
    const containerEl = desktopContainerRef.current;
    if (!containerEl || !finalRound) return;
    const containerRect = containerEl.getBoundingClientRect();
    if (containerRect.width === 0 || containerRect.height === 0) return;
    const next: Connector[] = [];
    for (const round of rounds) {
      const isFinal = round.id === finalRound.id;
      for (const match of round.matches) {
        (["aFrom", "bFrom"] as const).forEach((key, slotIdx) => {
          const feederLabel = match[key];
          if (!feederLabel) return;
          const sourceEl = cardEls.current[feederLabel];
          const targetEl = cardEls.current[match.id];
          if (!sourceEl || !targetEl) return;
          const sRect = sourceEl.getBoundingClientRect();
          const tRect = targetEl.getBoundingClientRect();
          if (sRect.width === 0 || tRect.width === 0) return;
          const sCenterX = sRect.left + sRect.width / 2;
          const tCenterX = tRect.left + tRect.width / 2;
          const flowsRight = sCenterX < tCenterX;
          const startX = (flowsRight ? sRect.right : sRect.left) - containerRect.left;
          const startY = sRect.top + sRect.height / 2 - containerRect.top;

          const team = slotIdx === 0 ? match.teamA : match.teamB;
          const teamCodeForConnector = team?.code || null;

          if (isFinal) {
            const targetRowEl = cardEls.current[`${match.id}:${slotIdx === 0 ? "A" : "B"}`] || targetEl;
            const trRect = targetRowEl.getBoundingClientRect();
            const endX = (flowsRight ? trRect.left : trRect.right) - containerRect.left;
            const endY = trRect.top + trRect.height / 2 - containerRect.top;
            next.push({
              id: `${match.id}-${slotIdx === 0 ? "A" : "B"}`,
              d: elbowPath(startX, startY, endX, endY),
              teamCode: teamCodeForConnector || undefined,
              sourceCode: teamCodeForConnector || undefined,
            });
            return;
          }
          const endX = tCenterX - containerRect.left;
          const endY = (slotIdx === 0 ? tRect.top : tRect.bottom) - containerRect.top;
          next.push({
            id: `${match.id}-${slotIdx === 0 ? "A" : "B"}`,
            d: topEntryPath(startX, startY, endX, endY),
            teamCode: teamCodeForConnector || undefined,
            sourceCode: teamCodeForConnector || undefined,
          });
        });
      }
    }
    setConnectors(next);
  }

  useLayoutEffect(() => {
    recomputeLayout();
    const raf = requestAnimationFrame(recomputeLayout);
    const ro = new ResizeObserver(() => recomputeLayout());
    if (desktopContainerRef.current) ro.observe(desktopContainerRef.current);
    window.addEventListener("resize", recomputeLayout);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      window.removeEventListener("resize", recomputeLayout);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rounds]);

  useLayoutEffect(() => {
    recomputeConnectors();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [matchCenterY, columnHeight]);

  function goToRound(idx: number) {
    const clamped = Math.max(0, Math.min(rounds.length - 1, idx));
    setMobileRound(clamped);
    const el = mobileScrollRef.current;
    if (el) el.scrollTo({ left: clamped * el.clientWidth, behavior: "smooth" });
  }

  function goToLabel(label: string | null) {
    const idx = roundIndexForLabel(label);
    if (idx >= 0) goToRound(idx);
  }

  function handleTeamClick(teamCode: string) {
    setSelectedTeamCode((prev) => (prev === teamCode ? null : teamCode));
  }

  useEffect(() => {
    const el = mobileScrollRef.current;
    if (!el) return;
    function onScroll() {
      if (!el) return;
      setMobileRound(Math.round(el.scrollLeft / el.clientWidth));
    }
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => el.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const roundId = rounds[mobileRound]?.id;
    const el = roundId !== undefined ? mobileVerticalRefs.current[roundId] : null;
    if (el) el.scrollTop = 0;
  }, [mobileRound, rounds]);

  const activeTeamCode = hoveredTeamCode || selectedTeamCode;

  useEffect(() => {
    onActiveTeamChange?.(activeTeamCode);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTeamCode]);

  if (!rounds || rounds.length === 0 || !finalRound) {
    return (
      <div className="min-h-[200px] w-full flex items-center justify-center text-outline font-label-mono text-sm">
        No bracket data provided.
      </div>
    );
  }

  return (
    <div className={`min-h-screen w-full bg-background text-on-surface p-2 md:p-2 ${className}`}>
      <style>{`
        html {
          scrollbar-width: thin;
          scrollbar-color: var(--color-border-overlay) transparent;
        }
        html::-webkit-scrollbar { width: 8px; height: 8px; }
        html::-webkit-scrollbar-track { background: transparent; }
        html::-webkit-scrollbar-thumb {
          background: var(--color-border-overlay);
          border-radius: 9999px;
          border: 2px solid var(--color-background);
          background-clip: padding-box;
        }
        html::-webkit-scrollbar-thumb:hover { background: var(--color-theme-orange); }
        .bracket-scrollbar-hidden::-webkit-scrollbar { display: none; }
        .bracket-scrollbar-hidden { scrollbar-width: none; -ms-overflow-style: none; }
        .bracket-scrollbar::-webkit-scrollbar { width: 6px; height: 6px; }
        .bracket-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .bracket-scrollbar::-webkit-scrollbar-thumb {
          background: var(--color-border-overlay);
          border-radius: 9999px;
          border: 1px solid transparent;
          background-clip: padding-box;
        }
        .bracket-scrollbar::-webkit-scrollbar-thumb:hover { background: var(--color-theme-orange); }
        .bracket-scrollbar { scrollbar-width: thin; scrollbar-color: var(--color-border-overlay) transparent; }
      `}</style>

      <div className="max-w-[1600px] mx-auto mt-2 md:my-4 flex flex-col px-8 md:flex-row items-start md:items-center justify-between gap-4 border-b border-border-overlay pb-6">
        <div>
          <span className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.3em] font-label-mono text-theme-orange">
            <Trophy className="w-3.5 h-3.5" />
            {eyebrowLabel}
          </span>
          <h1 className="font-headline-lg font-bold text-3xl md:text-4xl text-on-surface mt-1.5">{title}</h1>
        </div>
        <div className="flex items-center gap-4 bg-surface-container-low/70 backdrop-blur-xl px-4 py-2.5 rounded-xl border border-border-overlay">
          <div className="flex items-center gap-2">
            <span className="tally bg-[radial-gradient(circle_at_35%_30%,#ff9d94,var(--color-status-live)_65%)] shadow-[0_0_6px_1px_rgba(255,180,171,0.55)] animate-[connPulse_1.4s_ease-in-out_infinite]" />
            <span className="font-label-mono text-[10px] uppercase tracking-widest text-on-surface-variant">{liveLabel}</span>
          </div>
          <div className="w-px h-4 bg-border-overlay hidden md:block" />
          {selectedTeamCode ? (
            <button
              type="button"
              onClick={() => setSelectedTeamCode(null)}
              className="font-label-mono text-[11px] font-bold uppercase tracking-wide text-theme-orange hover:opacity-80 hidden md:block"
            >
              Tracing {selectedTeamCode} · click to release
            </button>
          ) : (
            <p className="font-body-md text-[11px] text-outline hidden md:block">{helperText}</p>
          )}
        </div>
      </div>

      <div className="hidden md:block max-w-[1600px] mx-auto relative" style={stageHeightStyle}>
        <div className="w-full h-full overflow-x-hidden overflow-y-hidden">
          {useMirroredLayout ? (
            <div ref={desktopContainerRef} className="relative flex items-stretch gap-0 w-full h-full pb-6">
              {finalCenter && logoSrc && (
                <div
                  className="absolute pointer-events-none z-0 flex justify-center items-center overflow-hidden"
                  style={{
                    left: finalCenter.x,
                    top: finalCenter.y,
                    transform: "translate(-50%, -50%)",
                    maxHeight: "100%",
                  }}
                >
                  <img
                    src={logoSrc}
                    alt=""
                    className="w-[280px] md:w-[450px] lg:w-[600px] max-w-none max-h-[85vh] h-auto object-contain opacity-15"
                  />
                </div>
              )}
              {nonFinalRounds.map((round, i) => {
                const isCompact = shouldBeCompact(i);
                const growWeight = getRoundGrowWeight(i, "left");
                const bleedLeft = i === 2 ? "-85%" : i === 3 ? "-85%" : undefined;
                const innerBleedLeft = i === 2 ? "-60%" : i === 3 ? "-60%" : undefined;

                return (
                  <BracketColumn
                    key={`L-${round.id}`}
                    roundName={round.name}
                    matches={leftSideMatches[i]}
                    centerYByMatchId={matchCenterY}
                    getRef={getRef}
                    hoveredTeamCode={activeTeamCode}
                    setHoveredTeamCode={setHoveredTeamCode}
                    onTeamClick={handleTeamClick}
                    pinnedTeamCode={selectedTeamCode}
                    compact={isCompact}
                    isLeaf={i === 0}
                    leafColumnRef={i === 0 ? (el) => (leafColumnRef.current = el) : undefined}
                    growWeight={growWeight}
                    bleedLeft={bleedLeft}
                    innerBleedLeft={innerBleedLeft}
                  />
                );
              })}
              <BracketColumn
                roundName={finalRound.name}
                matches={finalRound.matches}
                centerYByMatchId={matchCenterY}
                getRef={getRef}
                hoveredTeamCode={activeTeamCode}
                setHoveredTeamCode={setHoveredTeamCode}
                onTeamClick={handleTeamClick}
                pinnedTeamCode={selectedTeamCode}
                growWeight={getRoundGrowWeight(nonFinalRounds.length, "final")}
              />
              {[...nonFinalRounds].reverse().map((round, revIdx) => {
                const i = nonFinalRounds.length - 1 - revIdx;
                const isCompact = shouldBeCompact(i);
                const growWeight = getRoundGrowWeight(i, "right");
                const bleedRight = i === 2 ? "-85%" : i === 3 ? "-85%" : undefined;
                const innerBleedRight = i === 2 ? "-60%" : i === 3 ? "-60%" : undefined;

                return (
                  <BracketColumn
                    key={`R-${round.id}`}
                    roundName={round.name}
                    matches={rightSideMatches[i]}
                    centerYByMatchId={matchCenterY}
                    getRef={getRef}
                    hoveredTeamCode={activeTeamCode}
                    setHoveredTeamCode={setHoveredTeamCode}
                    onTeamClick={handleTeamClick}
                    pinnedTeamCode={selectedTeamCode}
                    compact={isCompact}
                    isLeaf={i === 0}
                    growWeight={growWeight}
                    bleedRight={bleedRight}
                    innerBleedRight={innerBleedRight}
                  />
                );
              })}
              <svg className="absolute inset-0 pointer-events-none z-0" width="100%" height="100%">
                {connectors.map((c) => {
                  const active = c.teamCode && c.teamCode === activeTeamCode;
                  return (
                    <path
                      key={c.id}
                      d={c.d}
                      fill="none"
                      stroke={active ? "var(--color-theme-orange)" : "var(--color-border-overlay)"}
                      strokeWidth={active ? 3 : 1.5}
                      strokeOpacity={active ? 1 : 0.6}
                      style={{
                        transition: "stroke 0.3s ease-in-out, stroke-width 0.3s ease-in-out, stroke-opacity 0.3s ease-in-out",
                        filter: active ? "drop-shadow(0 0 8px rgba(201, 151, 31, 0.6))" : "none",
                      }}
                    />
                  );
                })}
              </svg>
            </div>
          ) : (
            <div ref={desktopContainerRef} className="relative flex items-stretch gap-0 w-full h-full pb-6">
              {finalCenter && logoSrc && (
                <div
                  className="absolute pointer-events-none z-0 flex justify-center items-center overflow-hidden"
                  style={{
                    left: finalCenter.x,
                    top: finalCenter.y,
                    transform: "translate(-50%, -50%)",
                    maxHeight: "100%",
                  }}
                >
                  <img
                    src={logoSrc}
                    alt=""
                    className="w-[280px] md:w-[450px] lg:w-[600px] max-w-none max-h-[85vh] h-auto object-contain opacity-10"
                  />
                </div>
              )}
              {rounds.map((round, i) => {
                const isCompact = shouldBeCompact(i);
                const growWeight = getRoundGrowWeight(i, "left");
                const bleedLeft = i === 2 ? "-85%" : i === 3 ? "-65%" : undefined;
                const innerBleedLeft = i === 2 ? "-20%" : i === 3 ? "-20%" : undefined;

                return (
                  <BracketColumn
                    key={round.id}
                    roundName={round.name}
                    matches={round.matches}
                    centerYByMatchId={matchCenterY}
                    getRef={getRef}
                    hoveredTeamCode={activeTeamCode}
                    setHoveredTeamCode={setHoveredTeamCode}
                    onTeamClick={handleTeamClick}
                    pinnedTeamCode={selectedTeamCode}
                    isLeaf={i === 0}
                    leafColumnRef={i === 0 ? (el) => (leafColumnRef.current = el) : undefined}
                    growWeight={growWeight}
                    compact={isCompact}
                    bleedLeft={bleedLeft}
                    innerBleedLeft={innerBleedLeft}
                  />
                );
              })}
              <svg className="absolute inset-0 pointer-events-none z-0" width="100%" height="100%">
                {connectors.map((c) => {
                  const active = c.teamCode && c.teamCode === activeTeamCode;
                  return (
                    <path
                      key={c.id}
                      d={c.d}
                      fill="none"
                      stroke={active ? "var(--color-theme-orange)" : "var(--color-border-overlay)"}
                      strokeWidth={active ? 3 : 1.5}
                      strokeOpacity={active ? 1 : 0.6}
                      style={{
                        transition: "stroke 0.3s ease-in-out, stroke-width 0.3s ease-in-out, stroke-opacity 0.3s ease-in-out",
                        filter: active ? "drop-shadow(0 0 8px rgba(201, 151, 31, 0.6))" : "none",
                      }}
                    />
                  );
                })}
              </svg>
            </div>
          )}
        </div>
      </div>

      <div className="md:hidden max-w-xl mx-auto flex flex-col gap-4">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => goToRound(mobileRound - 1)}
            disabled={mobileRound === 0}
            className="w-9 h-9 shrink-0 rounded-full flex items-center justify-center bg-surface-container-low border border-border-overlay text-outline disabled:opacity-30 active:scale-95 transition-all"
            aria-label="Previous stage"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <div className="flex-1 flex items-center justify-center gap-1.5 overflow-x-auto bracket-scrollbar-hidden">
            {rounds.map((round, i) => (
              <button
                key={round.id}
                type="button"
                onClick={() => goToRound(i)}
                className={`shrink-0 px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest font-label-mono border transition-colors ${
                  i === mobileRound
                    ? "bg-theme-orange border-theme-orange text-on-primary"
                    : "bg-surface-container-low border-border-overlay text-outline"
                }`}
              >
                {round.shortName}
              </button>
            ))}
          </div>
          <button
            type="button"
            onClick={() => goToRound(mobileRound + 1)}
            disabled={mobileRound === rounds.length - 1}
            className="w-9 h-9 shrink-0 rounded-full flex items-center justify-center bg-surface-container-low border border-border-overlay text-outline disabled:opacity-30 active:scale-95 transition-all"
            aria-label="Next stage"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
        {selectedTeamCode && (
          <button
            type="button"
            onClick={() => setSelectedTeamCode(null)}
            className="self-center font-label-mono text-[10px] font-bold uppercase tracking-wide text-theme-orange hover:opacity-80"
          >
            Tracing {selectedTeamCode} · tap to release
          </button>
        )}
        <div
          ref={mobileScrollRef}
          className="flex overflow-x-auto snap-x snap-mandatory bracket-scrollbar-hidden"
          style={{ touchAction: "pan-x" }}
        >
          {rounds.map((round) => (
            <div key={round.id} className="w-full flex-shrink-0 snap-start">
              <h2 className="font-label-mono text-[11px] font-black uppercase tracking-widest text-on-surface-variant text-center mb-3">
                {round.name}
              </h2>
              <div
                ref={(el) => {
                  mobileVerticalRefs.current[round.id] = el;
                }}
                className="h-[65vh] overflow-y-auto bracket-scrollbar"
                style={{ touchAction: "pan-y", overscrollBehavior: "contain", WebkitOverflowScrolling: "touch" }}
              >
                <div className="min-h-full flex flex-col justify-center gap-3 py-2 px-1">
                  {round.matches.map((match) => (
                    <div key={match.id} className="w-full relative">
                      {round.id === finalRound.id && logoSrc && (
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none -z-10 w-full flex justify-center items-center">
                          <img
                            src={logoSrc}
                            alt=""
                            className="w-[250px] md:w-[350px] max-w-none h-auto object-contain opacity-10"
                          />
                        </div>
                      )}
                      <MatchCard
                        match={match}
                        hoveredTeamCode={activeTeamCode}
                        setHoveredTeamCode={setHoveredTeamCode}
                        onFromClick={goToLabel}
                        onTeamClick={handleTeamClick}
                        pinnedTeamCode={selectedTeamCode}
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}